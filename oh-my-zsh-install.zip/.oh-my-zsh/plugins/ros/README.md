# Roswell Plugin

This plugin adds completions and aliases for [Roswell](https://github.com/roswell/roswell/).

To use it, add `ros` to the plugins array in your zshrc file:

```zsh
plugins=(... ros)
```

