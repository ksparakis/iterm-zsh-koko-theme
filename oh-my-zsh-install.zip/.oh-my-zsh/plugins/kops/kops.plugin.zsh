if [ $commands[kops] ]; then
  source <(kops completion zsh)
fi
